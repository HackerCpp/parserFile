comboFilter.insertItem(0,"Медианный","median_filter.py")
comboFilter.insertItem(1,"Медианный с границами","median_filter_in_border.py")
comboFilter.insertItem(2,"Вставка шум","noise_function.py")
comboFilter.insertItem(3,"Усреднение","point_filter.py")