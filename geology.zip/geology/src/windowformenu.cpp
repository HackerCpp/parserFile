#include "windowformenu.h"

WindowForMenu::WindowForMenu(QWidget *parent) :
    QWidget(parent)
{

}

WindowForMenu::~WindowForMenu(){

}
